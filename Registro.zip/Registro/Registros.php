<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Visitantes</title>
    <link rel="stylesheet" href="css/visitante.css">
    <style>
        /* Estilos para el select */
        .select-container {
            display: flex;
            justify-content: center; /* Centra el elemento */
            margin: 10px 0; /* Espacio superior e inferior */
        }

        select {
            width: 100%; /* O 200px; puedes ajustar el tamaño */
            padding: 10px; /* Espacio interno */
            border: 1px solid #ccc; /* Borde */
            border-radius: 5px; /* Esquinas redondeadas */
            font-size: 16px; /* Tamaño de la fuente */
            background-color: #f9f9f9; /* Color de fondo */
            appearance: none; /* Quita el estilo predeterminado del navegador */
            -webkit-appearance: none; /* Para Safari */
            -moz-appearance: none; /* Para Firefox */
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="gray" style="width: 12px; height: 12px;"><polygon points="0,0 20,0 10,10"/></svg>'); /* Añade un icono de flecha */
            background-repeat: no-repeat;
            background-position: right 10px center; /* Posición del icono */
        }
    </style>
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD REGISTRO DE VISITANTES</h1>
        <p>Regístrate para acceder a eventos especiales y conocer más sobre nuestras actividades.</p>
    </div>

    <div class="container">
        <!-- Sección de Registro de Entrada -->
        <div class="registro">
            <h2>Registro de Entrada</h2>
            <form action="registro_visitante.php" method="POST">
                <div>
                    <label for="nombre">Nombre Completo</label>
                    <input type="text" id="nombre" name="nombre" required>
                </div>
                <div>
                    <label for="correo">Correo Electrónico</label>
                    <input type="email" id="correo" name="correo" required>
                </div>
                <div>
                    <label for="telefono">Teléfono</label>
                    <input type="tel" id="telefono" name="telefono" required>
                </div>
                <div>
                    <label for="motivo">Motivo de la Visita</label>
                    <div class="select-container">
                        <select id="motivo" name="motivo" required>
                            <option value="" disabled selected>Seleccione un motivo</option>
                            <option value="Reunión">Reunión</option>
                            <option value="Entrevista">Entrevista</option>
                            <option value="Visita a cliente">Visita a cliente</option>
                            <option value="Presentación de proyecto">Presentación de proyecto</option>
                            <option value="Capacitación">Capacitación</option>
                            <option value="Asistencia a evento">Asistencia a evento</option>
                            <option value="Visita familiar">Visita familiar</option>
                            <option value="Consultoría">Consultoría</option>
                            <option value="Revisión de trabajo">Revisión de trabajo</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label for="curp">CURP</label>
                    <div class="curp-container">
                        <input type="text" id="curp" name="curp" maxlength="18" pattern="[A-Z0-9]{18}" required>
                    </div>
                </div>
                
                <!-- Credencial asignada automáticamente desde PHP -->
                <div>
                    <label for="credencial">Credencial Asignada</label>
                    <input type="text" id="credencial" name="credencial" value="<?php echo isset($credencial_disponible) ? $credencial_disponible : ''; ?>" readonly>
                </div>

                <!-- Hora de entrada asignada automáticamente con JavaScript -->
                <input type="hidden" name="hora_entrada" id="hora_entrada">
                <input type="hidden" name="tipo" value="entrada">
                <div style="grid-column: span 2;">
                    <input type="submit" value="Registrar Entrada">
                </div>
            </form>
        </div>

        <!-- Sección de Registro de Salida -->
        <div class="registro">
            <h2>Registro de Salida</h2>
            <form action="registro_visitante.php" method="POST">
                <div>
                    <label for="correo-salida">Correo Electrónico</label>
                    <input type="email" id="correo-salida" name="correo" required>
                </div>
                <input type="hidden" name="tipo" value="salida">
                <div style="grid-column: span 2;">
                    <input type="submit" value="Registrar Salida">
                </div>
            </form>
        </div>

    <?php include 'footer/footer.php'; ?>

    <script>
        // Guardar la hora local del dispositivo en el campo oculto
        document.getElementById('hora_entrada').value = new Date().toISOString().slice(0, 19).replace('T', ' ');
    </script>
    <script src="js/visitante.js"></script>
</body>

</html>
