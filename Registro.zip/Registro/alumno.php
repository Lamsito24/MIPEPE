<?php
include 'conexion.php';

// Asumimos que obtenemos el ID del alumno de la URL o sesión
$id_alumno = 2; // Cambiar según corresponda

// Consultar los datos del alumno
$sql_alumno = "SELECT * FROM alumnos WHERE id_alumno = $id_alumno"; 
$result_alumno = $conn->query($sql_alumno);

// Inicializamos variables para almacenar los datos del alumno
if ($result_alumno && $result_alumno->num_rows > 0) {
    $row = $result_alumno->fetch_assoc();
    $nombre_alumno = $row['nombre'];
    $matricula = $row['matricula'];
    $turno = $row['turno'];
    $grado = $row['grado'];
    $grupo = $row['grupo'];
    $correo_alumno = $row['correo'];
    $orientador = $row['orientador'];
    $vigencia = $row['vigencia'];
    $ultima_entrada = $row['ultima_entrada'];
    $ultima_salida = $row['ultima_salida'];
    $faltas = $row['faltas'];
} else {
    echo "No se encontraron datos para el alumno.";
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Alumno</title>
    <link rel="stylesheet" href="css/alumno.css">
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD ALUMNO</h1>
    </div>

    <section class="perfil-alumno">
        <h2>Datos personales:</h2>
        <form class="formulario-hijo" method="POST" action="perfil-alumno.php">
            <div class="form-group">
                <label for="nombre">Nombre completo:</label>
                <input type="text" id="nombre" value="<?php echo htmlspecialchars($nombre_alumno); ?>" placeholder="Nombre del alumno">
            </div>
            <div class="form-group">
                <label for="matricula">Matrícula:</label>
                <input type="text" id="matricula" value="<?php echo htmlspecialchars($matricula); ?>" placeholder="Matrícula del alumno">
            </div>
            <div class="form-group">
                <label for="turno">Turno:</label>
                <input type="text" id="turno" value="<?php echo htmlspecialchars($turno); ?>" placeholder="Turno del alumno">
            </div>
            <div class="form-group">
                <label for="grado">Grado:</label>
                <input type="text" id="grado" value="<?php echo htmlspecialchars($grado); ?>" placeholder="Grado del alumno">
            </div>
            <div class="form-group">
                <label for="grupo">Grupo:</label>
                <input type="text" id="grupo" value="<?php echo htmlspecialchars($grupo); ?>" placeholder="Grupo del alumno">
            </div>
            <div class="form-group">
                <label for="correo">Correo electrónico:</label>
                <input type="email" id="correo" value="<?php echo htmlspecialchars($correo_alumno); ?>" placeholder="Correo del alumno">
            </div>
            <div class="form-group">
                <label for="orientador">Orientador:</label>
                <input type="text" id="orientador" value="<?php echo htmlspecialchars($orientador); ?>" placeholder="Nombre del orientador">
            </div>
            <div class="form-group">
                <label for="vigencia">Vigencia de credencial:</label>
                <input type="date" id="vigencia" value="<?php echo htmlspecialchars($vigencia); ?>">
            </div>

            <h2>Monitoreo:</h2>
            <div class="monitoreo-alumno">
                <div class="form-group">
                    <label for="ultima-entrada">Última Entrada:</label>
                    <input type="text" id="ultima-entrada" value="<?php echo htmlspecialchars($ultima_entrada); ?>" placeholder="Fecha y hora" readonly>
                </div>
                <div class="form-group">
                    <label for="ultima-salida">Última Salida:</label>
                    <input type="text" id="ultima-salida" value="<?php echo htmlspecialchars($ultima_salida); ?>" placeholder="Fecha y hora" readonly>
                </div>
                <div class="form-group">
                    <label for="faltas">Número de faltas:</label>
                    <input type="text" id="faltas" value="<?php echo htmlspecialchars($faltas); ?>" placeholder="Número de faltas" readonly>
                </div>
            </div>

            <h2>Registros:</h2>
            <div class="registros-alumno">
                <div class="registro">
                    <h3>Entradas a la institución</h3>
                    <p>Consulte sus registros de entrada a la institución.</p>
                    <button type="button" class="btn-ver-registros" onclick="mostrarRegistros('entrada')">VER REGISTROS</button>
                    <table class="tabla-registros" id="tabla-entradas">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo htmlspecialchars($ultima_entrada); ?></td>
                                <td><?php echo htmlspecialchars($ultima_entrada); // Ajusta si hay un campo específico para la hora ?></td>
                           </tr>
                        </tbody>
                    </table>
                </div>
                <div class="registro">
                    <h3>Salidas de la institución</h3>
                    <p>Consulte sus registros de salida de la institución.</p>
                    <button type="button" class="btn-ver-registros" onclick="mostrarRegistros('salida')">VER REGISTROS</button>
                    <table class="tabla-registros" id="tabla-salidas">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                           <tr>
                                <td><?php echo htmlspecialchars($ultima_salida); ?></td>
                                <td><?php echo htmlspecialchars($ultima_salida); // Ajusta si hay un campo específico para la hora ?></td>
                           </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>
    </section>

    <?php include 'footer/footer.php'; ?>

    <script src="js/alumno.js"></script>
    <script>
        function mostrarRegistros(tipo) {
            const tablaEntradas = document.getElementById('tabla-entradas');
            const tablaSalidas = document.getElementById('tabla-salidas');

            if (tipo === 'entrada') {
                tablaEntradas.style.display = tablaEntradas.style.display === 'none' ? 'table' : 'none';
                tablaSalidas.style.display = 'none'; // Ocultar salidas
            } else {
                tablaSalidas.style.display = tablaSalidas.style.display === 'none' ? 'table' : 'none';
                tablaEntradas.style.display = 'none'; // Ocultar entradas
            }
        }
    </script>
</body>
</html>