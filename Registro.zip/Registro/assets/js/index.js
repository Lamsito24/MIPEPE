// Crea el elemento de video
const video = document.createElement("video");

// Nuestro canvas
const canvasElement = document.getElementById("qr-canvas");
const canvas = canvasElement.getContext("2d");

// Botón o contenedor donde se activará el escaneo
const btnScanQR = document.getElementById("btn-scan-qr");

// Variable para controlar el estado de escaneo
let scanning = false;

// Función para encender la cámara
const encenderCamara = () => {
  navigator.mediaDevices
    .getUserMedia({ video: { facingMode: "environment" } })
    .then(function (stream) {
      scanning = true;
      btnScanQR.hidden = true;
      canvasElement.hidden = false;
      video.setAttribute("playsinline", true); // iOS Safari no debe estar en fullscreen
      video.srcObject = stream;
      video.play();
      tick();
      scan();
    });
};

// Función para dibujar el video en el canvas
function tick() {
  if (!scanning) return; // Detener el proceso de dibujo si no se está escaneando

  canvasElement.height = video.videoHeight;
  canvasElement.width = video.videoWidth;
  canvas.drawImage(video, 0, 0, canvasElement.width, canvasElement.height);

  requestAnimationFrame(tick); // Continuar dibujando mientras esté escaneando
}

// Función para intentar escanear el código QR
function scan() {
  try {
    qrcode.decode();
  } catch (e) {
    if (scanning) {
      setTimeout(scan, 300); // Reintentar después de 300ms si aún estamos escaneando
    }
  }
}

// Función para apagar la cámara
const cerrarCamara = () => {
  video.srcObject.getTracks().forEach((track) => {
    track.stop(); // Detener todos los streams de la cámara
  });
  scanning = false; // Cambiar el estado de escaneo
  canvasElement.hidden = true;
  btnScanQR.hidden = false;
};

// Callback cuando se lee correctamente el código QR
qrcode.callback = (respuesta) => {
  if (respuesta) {
    cerrarCamara(); // Apagar la cámara después de escanear
    
    // Extraer el número de la credencial de la URL escaneada
    const url = new URL(respuesta);
    const credencial = url.searchParams.get("credencial");

    if (credencial) {
      // Redirigir o enviar el número de credencial al servidor para el registro
      registrarCredencial(credencial);
    } else {
      alert("No se pudo extraer la credencial del QR.");
    }
  }
};

// Función para registrar la credencial en el servidor
function registrarCredencial(credencial) {
  // Ejemplo de cómo podrías enviar la credencial al servidor
  fetch("http://localhost/Registro/registro_visitante.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `tipo=entrada&credencial=${credencial}`,
  })
    .then((response) => response.text())
    .then((data) => {
      alert("Registro completado con la credencial: " + credencial);
      console.log(data); // Para depuración
    })
    .catch((error) => {
      console.error("Error al registrar la credencial:", error);
    });
}

// Evento para mostrar la cámara al cargar la página
window.addEventListener('load', (e) => {
  encenderCamara();
});
