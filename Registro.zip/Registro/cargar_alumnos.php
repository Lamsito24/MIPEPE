<?php
// cargar_alumnos.php
include 'conexion.php';

if (isset($_GET['grupo'])) {
    $grupo = $_GET['grupo'];

    $stmt = $pdo->prepare("SELECT nombre FROM alumnos WHERE grupo = :grupo");
    $stmt->bindParam(':grupo', $grupo);
    $stmt->execute();

    $alumnos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($alumnos);
} else {
    echo json_encode([]);
}
?>
