<?php
include 'conexion.php'; // Incluir el archivo de conexión

$sql = "SELECT id, nombre FROM grupos";
$result = $conn->query($sql);

$grupos = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $grupos[] = $row;
    }
}

echo json_encode($grupos);

$conn->close();
?>
