<?php
// cargar_tareas.php
include 'conexion.php';

if (isset($_GET['grupo'])) {
    $grupo = $_GET['grupo'];

    $stmt = $pdo->prepare("SELECT nombre, tarea1, tarea2, tarea3, tarea4, tarea5 FROM tareas WHERE grupo = :grupo");
    $stmt->bindParam(':grupo', $grupo);
    $stmt->execute();

    $tareas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($tareas);
} else {
    echo json_encode([]);
}
?>
