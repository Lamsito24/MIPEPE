<?php
include 'conexion.php';

// Asumimos que obtenemos el ID del alumno de la URL o sesión
$id_alumno = 1; // Cambiar según corresponda

// Consultar los datos del alumno
$sql_alumno = "SELECT * FROM alumnos WHERE id_alumno = $id_alumno"; // Cambiado 'id' por 'id_alumno'
$result_alumno = $conn->query($sql_alumno);

// Verificar si hay resultados
if ($result_alumno->num_rows > 0) {
    // Obtener los datos del alumno
    $row = $result_alumno->fetch_assoc();
    $nombre_alumno = $row['nombre'];
    $matricula = $row['matricula'];
    $turno = $row['turno'];
    $grado = $row['grado'];
    $grupo = $row['grupo'];
    $correo_alumno = $row['correo'];
    $orientador = $row['orientador'];
    $vigencia = $row['vigencia'];
    $ultima_entrada = $row['ultima_entrada'];
    $ultima_salida = $row['ultima_salida'];
    $faltas = $row['faltas'];
} else {
    echo "No se encontraron datos para el alumno.";
}

// Cerrar la conexión
$conn->close();
?>