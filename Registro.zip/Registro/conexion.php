<?php
$servername = "localhost";  // Cambia si tu servidor de MySQL no es localhost
$username = "root";   // Cambia por el nombre de usuario de tu base de datos
$password = ""; // Cambia por tu contraseña
$dbname = "demo"; // Nombre de la base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("La conexión ha fallado: " . $conn->connect_error);
}
?>
