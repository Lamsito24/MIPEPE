<?php
// Incluir la conexión a la base de datos
include 'conexion.php';

// Consultar grupos
$gruposQuery = "SELECT * FROM grupos";
$gruposResult = $conn->query($gruposQuery);

// Consultar alumnos
$alumnosQuery = "SELECT * FROM alumnos";
$alumnosResult = $conn->query($alumnosQuery);

// Consultar personal
$personalQuery = "SELECT * FROM personal";
$personalResult = $conn->query($personalQuery);
?>

<!-- Apartado de Registro de Grupos -->
<div class="apartado-grupos">
    <h3>Seleccionar Grupo</h3>
    <label for="grupo">Grupo:</label>
    <select id="grupo">
        <?php while($grupo = $gruposResult->fetch_assoc()): ?>
            <option value="<?= $grupo['id']; ?>"><?= $grupo['nombre']; ?></option>
        <?php endwhile; ?>
    </select>

    <label for="grado">Grado:</label>
    <select id="grado">
        <option value="A">A</option>
    </select>

    <label for="turno">Turno:</label>
    <select id="turno">
        <option value="matutino">Matutino</option>
        <option value="vespertino">Vespertino</option>
    </select>
    <button id="buscar-grupo">Buscar</button>

    <div id="lista-grupos">
        <h3>Lista de Alumnos</h3>
        <ul id="lista-alumnos-grupos">
            <?php while($alumno = $alumnosResult->fetch_assoc()): ?>
                <li><?= $alumno['nombre']; ?> - Matrícula: <?= $alumno['matricula']; ?></li>
            <?php endwhile; ?>
        </ul>
    </div>
</div>

<!-- Apartado de Búsqueda por Matrícula -->
<div class="apartado-matricula">
    <h3>Buscar por Matrícula</h3>
    <label for="matricula">Matrícula:</label>
    <input type="text" id="matricula" placeholder="Ingresa matrícula">
    <button id="buscar-matricula">Buscar</button>

    <div id="datos-alumno">
        <!-- Datos del alumno se llenarán dinámicamente -->
    </div>
</div>

<!-- Apartado de Búsqueda de Personal -->
<div class="apartado-personal">
    <div id="lista-personal">
        <h3>Lista de Personal</h3>
        <h4>Turno Matutino</h4>
        <table>
            <thead>
                <tr>
                    <th>Nombre Completo</th>
                    <th>Cargo</th>
                    <th>Asistencias</th>
                    <th>Faltas</th>
                    <th>Permisos Otorgados</th>
                    <th>Permisos Solicitados</th>
                </tr>
            </thead>
            <tbody>
                <?php while($personal = $personalResult->fetch_assoc()): ?>
                    <?php if($personal['turno'] == 'matutino'): ?>
                        <tr>
                            <td><?= $personal['nombre']; ?></td>
                            <td><?= $personal['cargo']; ?></td>
                            <td><?= $personal['dias_asistidos']; ?></td>
                            <td><?= $personal['faltas']; ?></td>
                            <td><?= $personal['faltas_justificadas']; ?></td>
                            <td><?= $personal['permisos_solicitados']; ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endwhile; ?>
            </tbody>
        </table>

        <h4>Turno Vespertino</h4>
        <table>
            <thead>
                <tr>
                    <th>Nombre Completo</th>
                    <th>Cargo</th>
                    <th>Asistencias</th>
                    <th>Faltas</th>
                    <th>Permisos Otorgados</th>
                    <th>Permisos Solicitados</th>
                </tr>
            </thead>
            <tbody>
                <?php while($personal = $personalResult->fetch_assoc()): ?>
                    <?php if($personal['turno'] == 'vespertino'): ?>
                        <tr>
                            <td><?= $personal['nombre']; ?></td>
                            <td><?= $personal['cargo']; ?></td>
                            <td><?= $personal['dias_asistidos']; ?></td>
                            <td><?= $personal['faltas']; ?></td>
                            <td><?= $personal['faltas_justificadas']; ?></td>
                            <td><?= $personal['permisos_solicitados']; ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div id="asistencias">
        <!-- Detalles de asistencias se llenarán dinámicamente -->
    </div>
</div>

<!-- Apartado de Documentación Escolar -->
<div class="apartado-documentacion">
    <h3>Documentación Escolar</h3>
    <label for="documento">Seleccionar:</label>
    <select id="documento">
        <option value="plan-estudio">Planes de Estudio</option>
        <option value="reglamento">Reglamento</option>
        <option value="politicas">Políticas de la Institución</option>
    </select>
    <button id="mostrar-documentacion">Mostrar</button>

    <div id="resultado-documentacion">
        <!-- Resultados de documentación se llenarán dinámicamente -->
    </div>
</div>

<?php
// Cerrar la conexión
$conn->close();
?>
