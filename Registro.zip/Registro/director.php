<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Director</title>
    <link rel="stylesheet" href="css/director.css">
</head>

<body>

<?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD DIRECTOR</h1>
    </div>
    <div class="container">
        <div class="table">
            <h1>Orientadores:</h1>
        </div>
        <table class="orientadores-table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo electrónico</th>
                    <th>Grupos</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Juan Pérez</td>
                    <td>juan.perez@example.com</td>
                    <td>2A, 3B, 4C</td>
                    <td><button onclick="desglosarGrupo(1)">Inspeccionar</button></td>
                </tr>
                <tr>
                    <td>Maria López</td>
                    <td>maria.lopez@example.com</td>
                    <td>1A, 2B, 3C</td>
                    <td><button onclick="desglosarGrupo(2)">Inspeccionar</button></td>
                </tr>
                <tr>
                    <td>Carlos Ramírez</td>
                    <td>carlos.ramirez@example.com</td>
                    <td>3A, 4B, 5C</td>
                    <td><button onclick="desglosarGrupo(3)">Inspeccionar</button></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Apartado para mostrar grupos y alumnos, oculto inicialmente -->
    <div class="grupo-alumnos-section" style="display: none;">
        <h2 id="grupo-titulo">Grupos del Orientador</h2>

        <div class="grupo-info" id="grupo-info-1">
            <!-- Aquí se llenará la información del grupo -->
        </div>

        <div class="alumno-info" id="alumno-info-1">
            <!-- Aquí se llenará la información del alumno -->
        </div>
    </div>

    <?php include 'footer/footer.php'; ?>

    <!-- Llamar el archivo JavaScript externo -->
    <script src="js/director.js"></script>

</body>

</html>