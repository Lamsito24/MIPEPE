<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard de Visitantes</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD VISITANTES</h1>
        <p>Consulta el historial de visitantes a continuación:</p>
    </div>

    <div class="container">
        <h2>Historial de Visitantes</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Motivo de la Visita</th>
                    <th>Hora de Entrada</th>
                    <th>Hora de Salida</th>
                    <th>Fecha de Registro</th>
                    <th>Credencial</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Incluir archivo de conexión a la base de datos
                include 'conexion.php';

                // Consultar historial de visitantes
                $query = "SELECT * FROM historial_visitantes ORDER BY fecha_registro DESC";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    // Mostrar cada fila de datos
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['nombre']}</td>
                            <td>{$row['correo']}</td>
                            <td>{$row['telefono']}</td>
                            <td>{$row['motivo']}</td>
                            <td>{$row['hora_entrada']}</td>
                            <td>{$row['hora_salida']}</td>
                            <td>{$row['fecha_registro']}</td>
                            <td>{$row['credencial']}</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No hay registros disponibles.</td></tr>";
                }

                // Cerrar conexión
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <?php include 'footer/footer.php'; ?>

    <script src="js/dashboard.js"></script>
</body>

</html>
