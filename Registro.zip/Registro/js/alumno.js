function generarDatosAleatorios(tipo) {
    const registros = [];
    const cantidad = 5; // Número de registros a generar

    for (let i = 0; i < cantidad; i++) {
        const fecha = new Date();
        fecha.setDate(fecha.getDate() - i); // Datos de los últimos días
        const hora = `${Math.floor(Math.random() * 24).toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`;
        registros.push({ fecha: fecha.toLocaleDateString(), hora: hora });
    }

    return registros;
}

function mostrarRegistros(tipo) {
    const tablaEntradas = document.getElementById('tabla-entradas');
    const tablaSalidas = document.getElementById('tabla-salidas');
    let registros;

    if (tipo === 'entrada') {
        registros = generarDatosAleatorios('entrada');
        tablaEntradas.style.display = 'table'; // Mostrar tabla de entradas
        tablaSalidas.style.display = 'none'; // Ocultar tabla de salidas
    } else {
        registros = generarDatosAleatorios('salida');
        tablaSalidas.style.display = 'table'; // Mostrar tabla de salidas
        tablaEntradas.style.display = 'none'; // Ocultar tabla de entradas
    }

    const tbody = tipo === 'entrada' ? tablaEntradas.querySelector('tbody') : tablaSalidas.querySelector('tbody');
    tbody.innerHTML = ''; // Limpiar filas anteriores

    // Llenar tabla con datos generados
    registros.forEach(registro => {
        const fila = document.createElement('tr');
        fila.innerHTML = `<td>${registro.fecha}</td><td>${registro.hora}</td>`;
        tbody.appendChild(fila);
    });
}