// Función para mostrar la información del grupo al hacer clic en "Inspeccionar"
function desglosarGrupo(grupoId) {
    // Mostrar la sección oculta
    document.querySelector('.grupo-alumnos-section').style.display = 'block';

    // Actualizar el título y la información de los grupos según el orientador seleccionado
    if (grupoId === 1) {
        document.getElementById('grupo-titulo').innerText = "Grupos del Orientador Juan Pérez";
        document.getElementById('grupo-info-1').innerHTML = `
            <p>GRUPO 2A:</p>
            <ul>
                <li>Alumno: Luis Martínez</li>
                <li>Edad: 15 años</li>
                <li>Promedio: 9.2</li>
            </ul>
            <button>Solicitar información del grupo.</button>
        `;
        document.getElementById('alumno-info-1').innerHTML = `
            <p>GRUPO 2A:</p>
            <ul>
                <li>Alumno: Ana Gómez</li>
                <li>Edad: 16 años</li>
                <li>Promedio: 9.8</li>
            </ul>
            <button>Solicitar información del alumno.</button>
        `;
    } else if (grupoId === 2) {
        document.getElementById('grupo-titulo').innerText = "Grupos del Orientador Maria López";
        document.getElementById('grupo-info-1').innerHTML = `
            <p>GRUPO 1A:</p>
            <ul>
                <li>Alumno: Juan Rodríguez</li>
                <li>Edad: 14 años</li>
                <li>Promedio: 8.5</li>
            </ul>
            <button>Solicitar información del grupo.</button>
        `;
        document.getElementById('alumno-info-1').innerHTML = `
            <p>GRUPO 2B:</p>
            <ul>
                <li>Alumno: Laura Méndez</li>
                <li>Edad: 15 años</li>
                <li>Promedio: 9.1</li>
            </ul>
            <button>Solicitar información del alumno.</button>
        `;
    } else if (grupoId === 3) {
        document.getElementById('grupo-titulo').innerText = "Grupos del Orientador Carlos Ramírez";
        document.getElementById('grupo-info-1').innerHTML = `
            <p>GRUPO 3A:</p>
            <ul>
                <li>Alumno: Pedro Gutiérrez</li>
                <li>Edad: 16 años</li>
                <li>Promedio: 8.9</li>
            </ul>
            <button>Solicitar información del grupo.</button>
        `;
        document.getElementById('alumno-info-1').innerHTML = `
            <p>GRUPO 4B:</p>
            <ul>
                <li>Alumno: María Santos</li>
                <li>Edad: 17 años</li>
                <li>Promedio: 9.0</li>
            </ul>
            <button>Solicitar información del alumno.</button>
        `;
    }
}
