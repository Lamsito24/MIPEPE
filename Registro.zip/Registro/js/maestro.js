// Función para generar un nombre completo aleatorio con uno o dos nombres y dos apellidos
function generarNombreCompleto() {
    const nombres = ['Juan', 'María', 'Carlos', 'Ana', 'Luis', 'Laura', 'José', 'Marta', 'Pedro', 'Carmen'];
    const apellidos = ['Pérez', 'Gómez', 'López', 'Hernández', 'Martínez', 'Díaz', 'Torres', 'Morales', 'Castillo', 'Rojas'];

    // Decidir si se usa un nombre o dos
    const nombre1 = nombres[Math.floor(Math.random() * nombres.length)];
    const nombre2 = Math.random() < 0.5 ? '' : ` ${nombres[Math.floor(Math.random() * nombres.length)]}`;
    
    const apellido1 = apellidos[Math.floor(Math.random() * apellidos.length)];
    const apellido2 = apellidos[Math.floor(Math.random() * apellidos.length)];

    return `${nombre1}${nombre2} ${apellido1} ${apellido2}`.trim();
}

// Función para generar los nombres de las tareas según el grupo
function generarTareasPorGrupo(grupo) {
    const tareasPorGrupo = {
        '1A': [
            'Llenado de formularios.pdf',
            'Investigación sobre historia.pdf',
            'Presentación de proyecto.pdf',
            'Ejercicio de matemáticas.pdf',
            'Ensayo sobre literatura.pdf'
        ],
        '2A': [
            'Resolución de problemas.pdf',
            'Análisis de textos.pdf',
            'Trabajo de ciencias.pdf',
            'Proyecto de arte.pdf',
            'Tarea de gramática.pdf'
        ],
        // Agrega más grupos y sus tareas aquí
    };

    return tareasPorGrupo[grupo] || [];
}

// Generar datos de alumnos con nombres completos aleatorios
const alumnosData = {
    '1A': Array.from({ length: 10 }, () => (generarDatosAlumno('1A'))),
    '2A': Array.from({ length: 10 }, () => (generarDatosAlumno('2A'))),
    // Agrega más grupos y alumnos aquí
};

function generarDatosAlumno(grupo) {
    const tareasNombres = generarTareasPorGrupo(grupo);
    const tareas = Array.from({ length: tareasNombres.length }, () => Math.random() < 0.5 ? 'Entregado' : 'No entregado');

    // Generar género aleatorio
    const genero = Math.random() < 0.5 ? 'Masculino' : 'Femenino';

    return {
        nombre: generarNombreCompleto(),
        tareas: tareas,
        presente: Array.from({ length: 5 }, () => Math.random() < 0.8), // 80% de probabilidades de estar presente
        tareasNombres: tareasNombres,
        evaluaciones: Array.from({ length: 5 }, () => Math.floor(Math.random() * 11)), // Calificaciones aleatorias de 0 a 10
        genero: genero // Añadir género
    };
}

// Evento para el botón de búsqueda de alumnos
document.getElementById('buscar-alumnos').addEventListener('click', function() {
    const grupoSeleccionado = document.getElementById('selector-grupo').value;
    const asistenciaLista = document.getElementById('asistencia-lista');
    const tareasLista = document.getElementById('tareas-lista');
    const evaluacionesLista = document.getElementById('evaluaciones-lista');
    const selectorAlumno = document.getElementById('selector-alumno');

    // Limpiar listas antes de llenar
    asistenciaLista.innerHTML = '';
    tareasLista.innerHTML = '';
    evaluacionesLista.innerHTML = '';
    selectorAlumno.innerHTML = '<option value="">-- Selecciona un alumno --</option>';
    document.getElementById('lista-tareas-subidas').innerHTML = '';
    document.getElementById('resultado-evaluacion').style.display = 'none'; // Ocultar resultados de evaluación al inicio

    if (grupoSeleccionado in alumnosData) {
        const alumnos = alumnosData[grupoSeleccionado];

        // Llenar lista de asistencia y tareas
        alumnos.forEach(alumno => {
            // Añadir visualización atractiva para presente o falta
            const asistencia = alumno.presente.map(p => p 
                ? '<span style="color: green;">&#x2705;</span>' // Paloma verde
                : '<span style="color: red;">&#x274C;</span>'); // X roja

            asistenciaLista.innerHTML += `<tr><td>${alumno.nombre}</td>${asistencia.map(icono => `<td>${icono}</td>`).join('')}</tr>`;
            tareasLista.innerHTML += `<tr><td>${alumno.nombre}</td>${alumno.tareas.map(tarea => {
                return tarea === 'Entregado' 
                    ? '<td><span style="color: green;">&#x2705;</span></td>' // Paloma
                    : '<td><span style="color: red;">&#x274C;</span></td>'; // X
            }).join('')}</tr>`;
            
            // Calcular promedio y redondear a un decimal
            const promedio = (alumno.evaluaciones.reduce((sum, grade) => sum + grade, 0) / alumno.evaluaciones.length).toFixed(1);
            evaluacionesLista.innerHTML += `<li>${alumno.nombre}: Promedio ${promedio}</li>`;

            // Llenar selector de alumnos
            const option = document.createElement('option');
            option.value = alumno.nombre;
            option.textContent = alumno.nombre;
            selectorAlumno.appendChild(option);
        });

        // Calcular resultados de evaluación
        calcularResultadosEvaluacion(alumnos);
    } else {
        alert('Grupo no encontrado.');
    }
});

// Función para calcular y mostrar resultados de evaluación
function calcularResultadosEvaluacion(alumnos) {
    const aprobados = alumnos.filter(alumno => {
        const promedio = (alumno.evaluaciones.reduce((sum, grade) => sum + grade, 0) / alumno.evaluaciones.length);
        return promedio >= 6; // Considera aprobado si el promedio es mayor o igual a 6
    });

    const reprobados = alumnos.filter(alumno => {
        const promedio = (alumno.evaluaciones.reduce((sum, grade) => sum + grade, 0) / alumno.evaluaciones.length);
        return promedio < 6; // Considera reprobado si el promedio es menor a 6
    });

    // Mostrar resultados
    const porcentajeAprobacion = ((aprobados.length / alumnos.length) * 100).toFixed(2);
    const porcentajeReprobados = ((reprobados.length / alumnos.length) * 100).toFixed(2);

    document.getElementById('porcentaje-aprobacion-texto').textContent = `Porcentaje de Aprobación: ${porcentajeAprobacion}%`;
    document.getElementById('porcentaje-reprobados-texto').textContent = `Porcentaje de Reprobados: ${porcentajeReprobados}%`;
    document.getElementById('resultado-evaluacion').style.display = 'block'; // Mostrar sección de resultados de evaluación

    // Listar alumnos reprobados
    const alumnosReprobadosLista = document.getElementById('alumnos-reprobados-lista');
    alumnosReprobadosLista.innerHTML = ''; // Limpiar lista existente
    reprobados.forEach(alumno => {
        const li = document.createElement('li');
        li.textContent = alumno.nombre;
        alumnosReprobadosLista.appendChild(li);
    });

    // Listar materias reprobadas
    const materiasReprobadasLista = document.getElementById('materias-reprobadas-lista');
    materiasReprobadasLista.innerHTML = ''; // Limpiar lista existente
    reprobados.forEach(alumno => {
        alumno.evaluaciones.forEach((calificacion, index) => {
            if (calificacion < 6) {
                const li = document.createElement('li');
                li.textContent = `${alumno.nombre} reprobó la materia ${index + 1} con calificación ${calificacion}`;
                materiasReprobadasLista.appendChild(li);
            }
        });
    });

    // Contar géneros
    const generosCount = { Masculino: 0, Femenino: 0 };
    alumnos.forEach(alumno => {
        generosCount[alumno.genero]++;
    });

    // Mostrar información del grupo
    document.getElementById('genero-grupo').textContent = `Grupo ${alumnos.length} alumnos: ${generosCount.Masculino} Masculinos, ${generosCount.Femenino} Femeninos`;
}

// Función para mostrar las tareas entregadas de un alumno seleccionado
function mostrarTareasEntregadas() {
    const alumnoSeleccionado = document.getElementById('selector-alumno').value;
    const listaTareasSubidas = document.getElementById('lista-tareas-subidas');
    
    listaTareasSubidas.innerHTML = '';

    if (alumnoSeleccionado) {
        const grupoSeleccionado = document.getElementById('selector-grupo').value;
        const alumno = alumnosData[grupoSeleccionado].find(a => a.nombre === alumnoSeleccionado);

        if (alumno) {
            alumno.tareas.forEach((estado, index) => {
                if (estado === 'Entregado') {
                    const li = document.createElement('li');
                    li.textContent = `Tarea entregada: ${alumno.tareasNombres[index]}`;
                    listaTareasSubidas.appendChild(li);
                }
            });
        }
    }
}

// Evento para mostrar las tareas entregadas del alumno seleccionado
document.getElementById('selector-alumno').addEventListener('change', mostrarTareasEntregadas);
