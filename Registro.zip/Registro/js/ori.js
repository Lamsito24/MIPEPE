const alumnosData = {
    '1A': { padres: 10, alumnos: ['Juan Pérez Gómez', 'Ana Martínez López', 'Luis Rodríguez Torres', 'María Fernández Ruiz'], asistencias: [], datosGrafica: [10, 12, 9, 11, 8, 15] },
    '1B': { padres: 8, alumnos: ['Carlos García Romero', 'David Sánchez Morales', 'Laura González López'], asistencias: [], datosGrafica: [12, 9, 14, 10, 13, 7] },
    '2A': { padres: 12, alumnos: ['Pedro López Martínez', 'Isabel Díaz Rojas', 'José Sánchez Pérez'], asistencias: [], datosGrafica: [14, 10, 12, 13, 11, 9] },
    '2B': { padres: 6, alumnos: ['Marta Rodríguez Torres', 'Clara Pérez Fernández', 'Santiago Morales Díaz'], asistencias: [], datosGrafica: [9, 7, 8, 10, 6, 5] },
    '3A': { padres: 9, alumnos: ['Raúl Hernández Silva', 'Rosa Morales León', 'Pablo Torres Martínez'], asistencias: [], datosGrafica: [11, 15, 14, 12, 13, 10] },
    '3B': { padres: 11, alumnos: ['Eva López García', 'Diego Fernández Ruiz', 'Teresa Martínez Torres'], asistencias: [], datosGrafica: [8, 10, 9, 11, 12, 14] },
};

// Generar datos de asistencias aleatorias y alertas
function generarDatosAleatorios(grupo) {
    const alumnos = alumnosData[grupo].alumnos;
    const alertas = [];
    const fechaActual = new Date().toLocaleDateString('es-MX');

    // Generar asistencias aleatorias
    const fechas = ['2024-01-05', '2024-02-12', '2024-03-15', '2024-04-20', '2024-05-25', '2024-06-10', '2024-07-30'];
    fechas.forEach(fecha => {
        alumnos.forEach(alumno => {
            const horaEntrada = `08:00`;
            const horaSalida = `14:00`;
            alumnosData[grupo].asistencias.push({ alumno, fecha, entrada: horaEntrada, salida: horaSalida });
        });
    });

    // Añadir alertas con sanciones
    alertas.push(`El alumno ${alumnos[0]} (${grupo}) recibió una sanción por mal comportamiento el ${fechaActual}.`);
    alertas.push(`El alumno ${alumnos[1]} (${grupo}) llegó tarde el ${fechaActual}.`);
    alertas.push(`El alumno ${alumnos[2]} (${grupo}) no cumplió con las normas el ${fechaActual}.`);

    return alertas;
}

// Evento para el botón de selección de grupo
document.getElementById('seleccionar-grupo').addEventListener('click', function() {
    const grupoSeleccionado = document.getElementById('selector-grado').value;
    const infoGrupo = document.getElementById('informacion-grupo');
    const listaAlumnos = document.getElementById('lista-alumnos');
    const cantidadPadres = document.getElementById('cantidad-padres');
    const cantidadAlumnos = document.getElementById('cantidad-alumnos');
    const listaAsistencias = document.getElementById('lista-asistencias');
    const alertas = document.getElementById('alertas');
    const listaAlertas = document.getElementById('lista-alertas');
    const graficaAsistencias = document.getElementById('grafica-asistencias');
    
    // Limpiar contenido previo
    listaAlumnos.innerHTML = '';
    listaAsistencias.innerHTML = '';
    listaAlertas.innerHTML = '';
    
    if (grupoSeleccionado in alumnosData) {
        const { padres, alumnos, asistencias, datosGrafica } = alumnosData[grupoSeleccionado];

        // Mostrar información del grupo
        infoGrupo.style.display = 'block';
        cantidadPadres.innerText = `Número de Padres Registrados: ${padres}`;
        cantidadAlumnos.innerText = `Número de Alumnos Registrados: ${alumnos.length}`;
        alumnos.forEach(alumno => {
            const li = document.createElement('li');
            li.innerText = alumno;
            listaAlumnos.appendChild(li);
        });

        // Mostrar registro de asistencias
        asistencias.forEach(asistencia => {
            const li = document.createElement('li');
            li.innerText = `${asistencia.alumno} - ${asistencia.fecha}: Entrada ${asistencia.entrada}, Salida ${asistencia.salida}`;
            listaAsistencias.appendChild(li);
        });

        // Generar y mostrar datos de alertas
        const alertasGeneradas = generarDatosAleatorios(grupoSeleccionado);
        alertasGeneradas.forEach(alerta => {
            const li = document.createElement('li');
            li.innerText = alerta;
            listaAlertas.appendChild(li);
        });
        alertas.style.display = 'block';

        // Mostrar gráfica
        graficaAsistencias.style.display = 'block';
        const ctx = document.getElementById('graficaCanvas').getContext('2d');

        // Si la gráfica ya existe, la eliminamos
        if (graficaAsistencias.chart) {
            graficaAsistencias.chart.destroy();
        }

        // Crear nueva gráfica con animación
        const data = {
            labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio'],
            datasets: [{
                label: 'Asistencias',
                data: datosGrafica,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
                tension: 0.1
            }]
        };

        graficaAsistencias.chart = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
});
