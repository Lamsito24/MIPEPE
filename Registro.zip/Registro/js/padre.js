document.querySelector('.btn-ver-mas').addEventListener('click', function() {
    alert('Aquí se mostrarían más faltas en una versión completa.');
});

// Gráfica de ejemplo, se puede modificar para mostrar datos reales en el futuro.
const ctx = document.getElementById('graficaAlumno').getContext('2d');
const graficaAlumno = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Sept 1', 'Sept 2', 'Sept 3', 'Sept 4', 'Sept 5'],
        datasets: [{
            label: 'Entradas',
            data: [7, 8, 6, 7, 8],
            borderColor: '#007bff',
            fill: false
        }, {
            label: 'Salidas',
            data: [13, 14, 12, 13, 14],
            borderColor: '#d9534f',
            fill: false
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: {
                display: true,
                title: {
                    display: true,
                    text: 'Fecha'
                }
            },
            y: {
                display: true,
                title: {
                    display: true,
                    text: 'Hora'
                },
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});
