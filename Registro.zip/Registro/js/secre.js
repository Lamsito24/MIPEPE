const alumnosData = {
    '1A': [
        { nombre: 'Juan Pérez López', matricula: '001', turnos: ['matutino'], datos: { faltas: 2, dias_asistidos: 28, faltas_justificadas: 1 }},
        { nombre: 'María García Sánchez', matricula: '002', turnos: ['vespertino'], datos: { faltas: 1, dias_asistidos: 29, faltas_justificadas: 2 }},
        { nombre: 'Carlos Hernández Morales', matricula: '003', turnos: ['matutino'], datos: { faltas: 0, dias_asistidos: 30, faltas_justificadas: 0 }},
        { nombre: 'Laura Martínez Ruiz', matricula: '004', turnos: ['vespertino'], datos: { faltas: 3, dias_asistidos: 27, faltas_justificadas: 1 }},
        { nombre: 'Diego Ramírez Torres', matricula: '005', turnos: ['matutino'], datos: { faltas: 1, dias_asistidos: 29, faltas_justificadas: 2 }},
    ],
    '2A': [
        { nombre: 'Sofía Jiménez Ortega', matricula: '006', turnos: ['matutino'], datos: { faltas: 1, dias_asistidos: 29, faltas_justificadas: 2 }},
        { nombre: 'Fernando López Jiménez', matricula: '007', turnos: ['vespertino'], datos: { faltas: 0, dias_asistidos: 30, faltas_justificadas: 0 }},
        { nombre: 'Andrea Torres Castro', matricula: '008', turnos: ['matutino'], datos: { faltas: 2, dias_asistidos: 28, faltas_justificadas: 1 }},
        { nombre: 'Luis Miguel Silva', matricula: '009', turnos: ['vespertino'], datos: { faltas: 2, dias_asistidos: 28, faltas_justificadas: 1 }},
        { nombre: 'Isabel Hernández Castillo', matricula: '010', turnos: ['matutino'], datos: { faltas: 1, dias_asistidos: 29, faltas_justificadas: 2 }},
    ],
};

// Datos de personal
const personalData = {
    'matutino': [
        { nombre: 'Pedro González Méndez', cargo: 'maestro', horario: 'matutino', asistencias: { faltas: 1, dias_asistidos: 29, faltas_justificadas: 1 }},
        { nombre: 'Ana María Ruiz', cargo: 'maestro', horario: 'matutino', asistencias: { faltas: 0, dias_asistidos: 30, faltas_justificadas: 0 }},
        { nombre: 'Javier Martínez', cargo: 'conserje', horario: 'matutino', asistencias: { faltas: 2, dias_asistidos: 28, faltas_justificadas: 1 }},
    ],
    'vespertino': [
        { nombre: 'Patricia López Ramírez', cargo: 'maestro', horario: 'vespertino', asistencias: { faltas: 0, dias_asistidos: 30, faltas_justificadas: 0 }},
        { nombre: 'José Torres', cargo: 'conserje', horario: 'vespertino', asistencias: { faltas: 3, dias_asistidos: 27, faltas_justificadas: 1 }},
    ],
};

// Función para buscar alumnos por grupo y grado
document.getElementById('buscar-grupo').addEventListener('click', () => {
    const grupo = document.getElementById('grupo').value + document.getElementById('grado').value;
    const listaAlumnos = document.getElementById('lista-alumnos-grupos');
    listaAlumnos.innerHTML = '';

    if (alumnosData[grupo]) {
        alumnosData[grupo].forEach(alumno => {
            const li = document.createElement('li');
            li.textContent = `${alumno.nombre} - Matrícula: ${alumno.matricula}`;
            listaAlumnos.appendChild(li);
        });
    } else {
        listaAlumnos.innerHTML = '<li>No hay alumnos en este grupo.</li>';
    }
});

// Función para buscar alumno por matrícula
document.getElementById('buscar-matricula').addEventListener('click', () => {
    const matricula = document.getElementById('matricula').value;
    const datosAlumno = document.getElementById('datos-alumno');
    datosAlumno.innerHTML = '';

    for (const grupo in alumnosData) {
        const alumno = alumnosData[grupo].find(a => a.matricula === matricula);
        if (alumno) {
            datosAlumno.innerHTML = `
                <h4>${alumno.nombre}</h4>
                <p>Matricula: ${alumno.matricula}</p>
                <p>Faltas: ${alumno.datos.faltas}</p>
                <p>Días Asistidos: ${alumno.datos.dias_asistidos}</p>
                <p>Faltas Justificadas: ${alumno.datos.faltas_justificadas}</p>
            `;
            return;
        }
    }

    datosAlumno.innerHTML = '<p>No se encontró el alumno.</p>';
});

// Función para buscar personal por cargo y horario
document.getElementById('buscar-personal').addEventListener('click', () => {
    const cargo = document.getElementById('cargo').value;
    const horario = document.getElementById('horario').value;
    const listaPersonal = document.getElementById('lista-personal-datos');
    listaPersonal.innerHTML = '';

    const personalEnHorario = personalData[horario] || [];
    const personalFiltrado = personalEnHorario.filter(persona => persona.cargo === cargo);

    if (personalFiltrado.length > 0) {
        personalFiltrado.forEach(persona => {
            const li = document.createElement('li');
            li.textContent = `${persona.nombre} - Cargo: ${persona.cargo}`;
            listaPersonal.appendChild(li);
        });
    } else {
        listaPersonal.innerHTML = '<li>No hay personal en este horario.</li>';
    }

    // Mostrar detalles de asistencias
    let asistenciasHTML = '<h4>Asistencias:</h4><ul>';
    personalFiltrado.forEach(persona => {
        asistenciasHTML += `
            <li>${persona.nombre}: Faltas ${persona.asistencias.faltas}, Días Asistidos ${persona.asistencias.dias_asistidos}</li>
        `;
    });
    asistenciasHTML += '</ul>';
    document.getElementById('asistencias').innerHTML = asistenciasHTML;
});

// Función para mostrar datos financieros
document.getElementById('mostrar-finanzas').addEventListener('click', () => {
    const tipoFinanzas = document.getElementById('tipo-finanzas').value;
    const resultadoFinanzas = document.getElementById('resultado-finanzas');
    resultadoFinanzas.innerHTML = '';

    // Aquí deberías tener la lógica para obtener los datos financieros según el tipo seleccionado.
    // Este es un ejemplo básico.
    if (tipoFinanzas === 'estado-pago') {
        resultadoFinanzas.innerHTML = '<p>Estado de pago: Todos al corriente.</p>';
    } else if (tipoFinanzas === 'recibo') {
        resultadoFinanzas.innerHTML = '<p>Recibo generado correctamente.</p>';
    } else if (tipoFinanzas === 'matricula') {
        resultadoFinanzas.innerHTML = '<p>Matriculas abiertas hasta el 30 de septiembre.</p>';
    } else if (tipoFinanzas === 'cuota') {
        resultadoFinanzas.innerHTML = '<p>Cuotas de este mes: $500.</p>';
    } else {
        resultadoFinanzas.innerHTML = '<p>Tipo de finanzas no válido.</p>';
    }
});

// Función para mostrar documentación escolar
document.getElementById('mostrar-documentacion').addEventListener('click', () => {
    const documento = document.getElementById('documento').value;
    const resultadoDocumentacion = document.getElementById('resultado-documentacion');
    resultadoDocumentacion.innerHTML = '';

    // Aquí deberías tener la lógica para obtener la documentación según el tipo seleccionado.
    // Este es un ejemplo básico.
    if (documento === 'plan-estudio') {
        resultadoDocumentacion.innerHTML = '<p>Planes de Estudio disponibles para descargar.</p>';
    } else if (documento === 'reglamento') {
        resultadoDocumentacion.innerHTML = '<p>Reglamento de la Institución disponible para descarga.</p>';
    } else if (documento === 'politicas') {
        resultadoDocumentacion.innerHTML = '<p>Políticas de la Institución disponibles para consultar.</p>';
    } else {
        resultadoDocumentacion.innerHTML = '<p>Documento no válido.</p>';
    }
});
