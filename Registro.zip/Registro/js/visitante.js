function verMasFechas() {
    const masFechas = document.querySelector('.mas-fechas');
    const boton = document.querySelector('.btn-ver-mas');
    
    if (masFechas.style.display === 'none' || masFechas.style.display === '') {
        masFechas.style.display = 'block';
        boton.textContent = 'Ver menos fechas conmemorativas';
    } else {
        masFechas.style.display = 'none';
        boton.textContent = 'Ver más fechas conmemorativas';
    }
}

// Animación para desplazarse al formulario de registro al hacer clic en "Quiero Registrarme"
document.querySelector('.btn-registro').addEventListener('click', () => {
    document.querySelector('.registro').scrollIntoView({ behavior: 'smooth' });
    
});
function validarCURP(curp) {
    // Expresión regular para validar formato CURP
    const curpRegex = /^([A-Z]{4})(\d{6})([H|M])([A-Z]{2})([A-Z]{3})([A-Z0-9]\d)$/;
    
    // Eliminar espacios antes y después del CURP
    curp = curp.trim();

    // Verificar si el CURP coincide con el patrón
    return curpRegex.test(curp);
}

// Evento para validar el formulario antes de enviarlo
document.querySelector('#form-registro').addEventListener('submit', function(e) {
    const curp = document.querySelector('#curp').value;
    if (!validarCURP(curp)) {
        e.preventDefault(); // Evitar el envío del formulario
        alert('El CURP ingresado es inválido. Asegúrate de que sigue el formato correcto.');
    }
});
