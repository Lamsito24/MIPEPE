<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Alumnos</title>
    <link rel="stylesheet" href="css/maestro.css">
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD MAESTROS</h1>
    </div>

    <section class="registro-alumnos">
        <h2>Registro de Alumnos</h2>
        <label for="selector-grupo">Seleccionar Grupo:</label>
        <select id="selector-grupo">
            <option value="">-- Selecciona un grupo --</option>
            <option value="1A">1A</option>
            <option value="2A">2A</option>
        </select>

        <!-- Nuevo selector para buscar materia -->
        <label for="selector-materia">Seleccionar Materia:</label>
        <select id="selector-materia">
            <option value="">-- Selecciona una materia --</option>
            <option value="matematica">Matemáticas</option>
            <option value="espanol">Español</option>
            <option value="ingles">Inglés</option>
        </select>

        <button id="buscar-alumnos">Buscar</button>

        <div id="lista-asistencia">
            <h3>Lista de Asistencia</h3>
            <table id="asistencia-tabla">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Lunes</th>
                        <th>Martes</th>
                        <th>Miércoles</th>
                        <th>Jueves</th>
                        <th>Viernes</th>
                    </tr>
                </thead>
                <tbody id="asistencia-lista">
                    <!-- Lista de asistencia se llenará dinámicamente -->
                </tbody>
            </table>
        </div>

        <div id="lista-tareas">
            <h3>Tareas Entregadas</h3>
            <table id="tareas-tabla">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Tarea 1</th>
                        <th>Tarea 2</th>
                        <th>Tarea 3</th>
                        <th>Tarea 4</th>
                        <th>Tarea 5</th>
                    </tr>
                </thead>
                <tbody id="tareas-lista">
                    <!-- Lista de tareas se llenará dinámicamente -->
                </tbody>
            </table>
        </div>

        <div id="tareas-subidas">
            <h3>Tareas Subidas en PDF</h3>
            <label for="selector-alumno">Seleccionar Alumno:</label>
            <select id="selector-alumno" onchange="mostrarTareasEntregadas()">
                <!-- Opciones se llenarán dinámicamente -->
                <option value="">-- Selecciona un alumno --</option>
            </select>
            <div id="lista-tareas-subidas">
                <!-- Lista de tareas subidas se llenará dinámicamente -->
            </div>
        </div>

        <div id="evaluaciones">
            <h3>Evaluaciones</h3>
            <ul id="evaluaciones-lista">
                <!-- Lista de evaluaciones se llenará dinámicamente -->
            </ul>
        </div>
        
        <div id="resultado-evaluacion">
            <h3>Resultados de Evaluación</h3>
            
            <!-- Tabla para Porcentaje de Aprobación -->
            <h4>Porcentaje de Aprobación</h4>
            <table id="tabla-aprobacion">
                <thead>
                    <tr>
                        <th>Grupo</th>
                        <th>Porcentaje</th>
                    </tr>
                </thead>
                <tbody id="porcentaje-aprobacion-lista">
                    <!-- Lista de porcentaje de aprobación se llenará dinámicamente -->
                </tbody>
            </table>
            
            <!-- Tabla para Alumnos Reprobados -->
            <h4>Alumnos Reprobados</h4>
            <label for="selector-alumno-reprobado">Seleccionar Alumno Reprobado:</label>
            <select id="selector-alumno-reprobado">
                <option value="">-- Selecciona un alumno --</option>
                <!-- Opciones se llenarán dinámicamente -->
            </select>
            <table id="tabla-alumnos-reprobados">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Grupo</th>
                    </tr>
                </thead>
                <tbody id="alumnos-reprobados-lista">
                    <!-- Lista de alumnos reprobados se llenará dinámicamente -->
                </tbody>
            </table>
            
            <!-- Tabla para Materias Reprobadas -->
            <h4>Materias Reprobadas</h4>
            <label for="selector-materia-reprobada">Seleccionar Materia Reprobada:</label>
            <select id="selector-materia-reprobada">
                <option value="">-- Selecciona una materia --</option>
                <!-- Opciones se llenarán dinámicamente -->
            </select>
            <table id="tabla-materias-reprobadas">
                <thead>
                    <tr>
                        <th>Materia</th>
                        <th>Grupo</th>
                    </tr>
                </thead>
                <tbody id="materias-reprobadas-lista">
                    <!-- Lista de materias reprobadas se llenará dinámicamente -->
                </tbody>
            </table>

            <div id="detalles-materia-reprobada">
                <h4>Detalles de Materias Reprobadas</h4>
                <p id="info-reprobados"></p>
                <!-- Aquí se mostrará quién reprobó a los alumnos -->
            </div>

            <!-- Tabla para Género por Grupo -->
            <h4>Género por Grupo</h4>
            <table id="tabla-genero">
                <thead>
                    <tr>
                        <th>Grupo</th>
                        <th>Masculino</th>
                        <th>Femenino</th>
                    </tr>
                </thead>
                <tbody id="genero-grupo">
                    <!-- Lista de género por grupo se llenará dinámicamente -->
                </tbody>
            </table>
        </div>
    </section>

    <?php include 'footer/footer.php'; ?>

    <script src="js/maestro.js"></script>
</body>

</html>
