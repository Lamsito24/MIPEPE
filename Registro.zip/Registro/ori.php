<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Orientador</title>
    <link rel="stylesheet" href="css/ori.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #ecf0f1; /* Fondo claro */
        }
        .hero {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        h1, h2 {
            color: #2c3e50;
            margin-bottom: 10px; /* Espacio debajo de los encabezados */
        }
        .section {
            margin-bottom: 30px; /* Espacio entre secciones */
            background-color: #ffffff; /* Fondo blanco para las secciones */
            padding: 20px;
            border-radius: 8px; /* Bordes redondeados */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Sombra */
        }
        .formulario {
            background-color: #f9f9f9; /* Color de fondo suave */
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .formulario label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .formulario input, select {
            width: 100%;
            padding: 10px; /* Aumentar padding para mayor comodidad */
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box; /* Asegura que el padding no sume al ancho total */
        }
        button {
            background-color: #2980b9; /* Color de fondo del botón */
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px; /* Tamaño de fuente más grande */
        }
        button:hover {
            background-color: #3498db; /* Color del botón al pasar el mouse */
        }
        #informacion-grupo, #registro-asistencias, #grafica-asistencias, #alertas {
            display: none; /* Mantener ocultos inicialmente */
        }
    </style>
</head>
<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD ORIENTADOR</h1>
    </div>
    
    <div class="container">
        <!-- Datos del Orientador -->
        <div class="section">
            <h2>Datos del Orientador</h2>
            <form class="formulario" action="procesar_datos_orientador.php" method="POST">
                <label for="nombre-ori">Nombre Completo:</label>
                <input type="text" id="nombre-ori" name="nombre-ori" placeholder="Nombre del orientador" required>

                <label for="correo-ori">Correo Electrónico:</label>
                <input type="email" id="correo-ori" name="correo-ori" placeholder="Correo del orientador" required>

                <label for="telefono-ori">Teléfono:</label>
                <input type="tel" id="telefono-ori" name="telefono-ori" placeholder="Teléfono del orientador" required>

                <label for="grupo-ori">Grupo:</label>
                <input type="text" id="grupo-ori" name="grupo-ori" placeholder="Grupo asignado" required>
                
                <!-- Nuevo campo para el nombre de la escuela -->
                <label for="escuela-ori">Nombre de la Escuela:</label>
                <input type="text" id="escuela-ori" name="escuela-ori" placeholder="Nombre de la escuela" required>

                <button type="submit">Enviar</button>
            </form>
        </div>

        <!-- Registro de Alumnos -->
        
            <div id="informacion-grupo">
                <h3>Información del Grupo</h3>
                <p id="cantidad-padres">Número de Padres Registrados: </p>
                <p id="cantidad-alumnos">Número de Alumnos Registrados: </p>
                <ul id="lista-alumnos"></ul>
            </div>

            <div id="registro-asistencias">
                <h3>Registro de Asistencias Recientes</h3>
                <ul id="lista-asistencias"></ul>
            </div>

            <div id="grafica-asistencias">
                <h3>Gráfica de Asistencias</h3>
                <canvas id="graficaCanvas"></canvas>
            </div>

            <div id="alertas">
                <h3>Alertas</h3>
                <ul id="lista-alertas"></ul>
            </div>
        </section>

        <!-- Escanear -->
        <div class="section">
            <h2>Escanear</h2>
            <form class="formulario" action="procesar_escanear.php" method="POST">
                <label for="escanear">Escanear entrada/salida de todos los alumnos:</label>
                <input type="text" id="escanear" name="escanear" placeholder="Código de escaneo" required>
                <button type="submit">Enviar</button>
            </form>
        </div>

        <!-- Visualizar -->
        <div class="section">
            <h2>Visualizar</h2>
            <form class="formulario" action="procesar_visualizar.php" method="POST">
                <label for="promedio">Consultar promedio de sus alumnos:</label>
                <input type="text" id="promedio" name="promedio" placeholder="Promedio de los alumnos" required>

                <label for="aprobacion">Consultar porcentajes de aprobación de sus grupos:</label>
                <input type="text" id="aprobacion" name="aprobacion" placeholder="Porcentaje de aprobación" required>

                <label for="materias-aprobadas">Consultar materias aprobadas de sus grupos:</label>
                <input type="text" id="materias-aprobadas" name="materias-aprobadas" placeholder="Materias aprobadas" required>

                <label for="reprobacion">Consultar porcentajes de reprobación de sus grupos:</label>
                <input type="text" id="reprobacion" name="reprobacion" placeholder="Porcentaje de reprobación" required>

                <label for="maestros-reprobados">Consultar maestros que más reprobaron de sus grupos:</label>
                <input type="text" id="maestros-reprobados" name="maestros-reprobados" placeholder="Maestros reprobados" required>

                <label for="materias-reprobadas">Consultar materias reprobadas de sus grupos:</label>
                <input type="text" id="materias-reprobadas" name="materias-reprobadas" placeholder="Materias reprobadas" required>

                <label for="desercion">Consultar índice de deserción de sus grupos:</label>
                <input type="text" id="desercion" name="desercion" placeholder="Índice de deserción" required>

                <label for="eficiencia">Consultar la eficiencia terminal de sus grupos:</label>
                <input type="text" id="eficiencia" name="eficiencia" placeholder="Eficiencia terminal" required>

                <label for="genero">Consultar género de sus grupos:</label>
                <input type="text" id="genero" name="genero" placeholder="Género de los grupos" required>

                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>

    <script>
        // Aquí va tu código de JavaScript para manejar las interacciones y la lógica
    </script>
</body>
</html>
