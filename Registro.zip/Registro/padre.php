<?php
// Incluir la conexión a la base de datos
include 'conexion.php';

// Supongamos que tienes el id del padre (puedes obtenerlo de la sesión o de otro modo)
$id_padre = 3; // Cambia esto por el id correspondiente del padre

// Consulta para obtener los datos del padre
$sql_padre = "SELECT * FROM padres WHERE id_padre = $id_padre"; 
$result_padre = $conn->query($sql_padre);

// Inicializamos variables para almacenar los datos del padre
if ($result_padre && $result_padre->num_rows > 0) {
    $row_padre = $result_padre->fetch_assoc();
    $nombre_padre = $row_padre['nombre_padre'];
    $correo_padre = $row_padre['correo_padre'];
    $telefono_padre = $row_padre['telefono_padre'];
    $direccion_padre = $row_padre['direccion_padre'];
    $id_alumno = $row_padre['id_alumno']; // Guardamos el id_alumno para la siguiente consulta
} else {
    echo "No se encontraron datos para el padre.";
    exit; // Salimos del script si no encontramos al padre
}

// Ahora consultamos los datos del alumno relacionado con el padre
$sql_alumno = "SELECT * FROM alumnos WHERE id_alumno = $id_alumno"; 
$result_alumno = $conn->query($sql_alumno);

// Inicializamos variables para almacenar los datos del alumno
if ($result_alumno && $result_alumno->num_rows > 0) {
    $row_alumno = $result_alumno->fetch_assoc();
    $nombre_alumno = $row_alumno['nombre'];
    $grado = $row_alumno['grado'];
    $escuela = $row_alumno['escuela'];
    $ultima_entrada = $row_alumno['ultima_entrada']; // Asumimos que está en la tabla alumnos
    $ultima_salida = $row_alumno['ultima_salida']; // Asumimos que está en la tabla alumnos

    // Consulta para obtener el historial de faltas del alumno
    $sql_faltas = "SELECT fecha FROM faltas WHERE id_alumno = $id_alumno ORDER BY fecha DESC"; // Asegúrate de tener la tabla de faltas
    $result_faltas = $conn->query($sql_faltas);
    $faltas = [];
    if ($result_faltas && $result_faltas->num_rows > 0) {
        while ($row_falta = $result_faltas->fetch_assoc()) {
            $faltas[] = $row_falta['fecha']; // Suponiendo que tienes un campo 'fecha'
        }
    }
} else {
    echo "No se encontraron datos para el alumno relacionado.";
    exit; // Salimos del script si no encontramos al alumno
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Padre</title>
    <link rel="stylesheet" href="css/padre.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD PADRE DE FAMILIA</h1>
    </div>

    <section class="perfil-padre">
        <h2>Datos del Padre</h2>
        <form class="formulario-padre">
            <label for="nombre-padre">Nombre Completo:</label>
            <input type="text" id="nombre-padre" name="nombre-padre" value="<?php echo htmlspecialchars($nombre_padre); ?>" readonly>

            <label for="correo-padre">Correo Electrónico:</label>
            <input type="email" id="correo-padre" name="correo-padre" value="<?php echo htmlspecialchars($correo_padre); ?>" readonly>

            <label for="telefono-padre">Teléfono:</label>
            <input type="tel" id="telefono-padre" name="telefono-padre" value="<?php echo htmlspecialchars($telefono_padre); ?>" readonly>

            <label for="direccion-padre">Dirección:</label>
            <input type="text" id="direccion-padre" name="direccion-padre" value="<?php echo htmlspecialchars($direccion_padre); ?>" readonly>
        </form>

        <h2>Datos del Hijo</h2>
        <form class="formulario-hijo">
            <label for="nombre-hijo">Nombre del Hijo:</label>
            <input type="text" id="nombre-hijo" name="nombre-hijo" value="<?php echo htmlspecialchars($nombre_alumno); ?>" readonly>

            <label for="grado-hijo">Grado:</label>
            <input type="text" id="grado-hijo" name="grado-hijo" value="<?php echo htmlspecialchars($grado); ?>" readonly>

            <label for="escuela-hijo">Escuela:</label>
            <input type="text" id="escuela-hijo" name="escuela-hijo" value="<?php echo htmlspecialchars($escuela); ?>" readonly>

            <label for="ultima-entrada">Última Entrada:</label>
            <input type="text" id="ultima-entrada" name="ultima-entrada" value="<?php echo htmlspecialchars($ultima_entrada); ?>" readonly>

            <label for="ultima-salida">Última Salida:</label>
            <input type="text" id="ultima-salida" name="ultima-salida" value="<?php echo htmlspecialchars($ultima_salida); ?>" readonly>
        </form>

        <div class="grafica-alumno">
            <h2>Gráfica del Alumno</h2>
            <canvas id="graficaAlumno"></canvas>
            <script>
                const ctx = document.getElementById('graficaAlumno').getContext('2d');
                const graficaAlumno = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4'], // Cambia por las etiquetas de tu preferencia
                        datasets: [{
                            label: 'Asistencia',
                            data: [1, 0, 1, 0], // Cambia esto por los datos de asistencia reales
                            borderColor: 'rgba(75, 192, 192, 1)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            </script>
        </div>

        <div class="historial-faltas">
            <h2>Historial de Asistencia</h2>
            <ul>
                <?php foreach ($faltas as $falta): ?>
                    <li>Falta el <?php echo htmlspecialchars($falta); ?></li>
                <?php endforeach; ?>
            </ul>
            <button class="btn-ver-mas">Ver más faltas</button>
        </div>
    </section>

    <?php include 'footer/footer.php'; ?>

    <script src="js/padre.js"></script>
</body>
</html>