<?php
include 'conexion.php'; // Incluir la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener datos del formulario
    $nombre_hijo = $_POST['nombre-hijo'];
    $grado_hijo = $_POST['grado-hijo'];
    $escuela_hijo = $_POST['escuela-hijo'];
    $ultima_entrada = $_POST['ultima-entrada'];
    $ultima_salida = $_POST['ultima-salida'];

    // Obtener ID del padre para asociarlo
    $id_padre = 1; // Puedes modificar esto para que coincida con el ID real del padre

    // Insertar datos en la base de datos
    $sql = "INSERT INTO hijos (nombre_hijo, grado_hijo, escuela_hijo, ultima_entrada, ultima_salida, id_padre)
            VALUES ('$nombre_hijo', '$grado_hijo', '$escuela_hijo', '$ultima_entrada', '$ultima_salida', '$id_padre')";

    if ($conn->query($sql) === TRUE) {
        echo "Datos del hijo guardados correctamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
