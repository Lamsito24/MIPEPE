<?php
include 'conexion.php'; // Incluir la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener datos del formulario
    $nombre_padre = $_POST['nombre-padre'];
    $correo_padre = $_POST['correo-padre'];
    $telefono_padre = $_POST['telefono-padre'];
    $direccion_padre = $_POST['direccion-padre'];

    // Insertar datos en la base de datos
    $sql = "INSERT INTO padres (nombre_padre, correo_padre, telefono_padre, direccion_padre)
            VALUES ('$nombre_padre', '$correo_padre', '$telefono_padre', '$direccion_padre')";

    if ($conn->query($sql) === TRUE) {
        echo "Datos del padre guardados correctamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
