<?php
// Incluir el archivo de conexión a la base de datos
include 'conexion.php';

// Mostrar errores de PHP (solo para depuración, luego puedes desactivarlo)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Establecer la zona horaria
date_default_timezone_set('America/Mexico_City');

// Función para obtener la credencial disponible
function obtenerCredencialDisponible($conn) {
    $stmt = $conn->prepare("SELECT credencial FROM credenciales WHERE estado = 'disponible' ORDER BY credencial ASC LIMIT 1");
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        return $row['credencial']; // Retorna la credencial disponible
    } else {
        return null; // No hay credenciales disponibles
    }
}

// Función para validar el CURP
function validarCURP($curp) {
    $curpRegex = '/^([A-Z]{4})(\d{6})([H|M])([A-Z]{2})([A-Z]{3})([A-Z0-9]\d)$/';
    $curp = trim($curp); // Eliminar espacios
    return preg_match($curpRegex, $curp);
}

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo = $_POST['tipo'];
    $correo = $_POST['correo'];

    // Registro de entrada
    if ($tipo == "entrada") {
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];
        $curp = $_POST['curp'];
        $motivo = $_POST['motivo'];
        $hora_entrada = date('Y-m-d H:i:s');
        $credencial = obtenerCredencialDisponible($conn); // Obtener una credencial disponible

        if (!validarCURP($curp)) {
            echo "El CURP ingresado es inválido.";
            exit();
        }

        if (!empty($nombre) && !empty($correo) && !empty($telefono) && !empty($curp) && !empty($motivo) && !is_null($credencial)) {
            // Generar el QR (asumimos que ya tienes el código para generarlo)
            $qr_code = 'http://localhost/Registro/Registros.php?credencial=' . $credencial; 

            // Insertar en la tabla visitantes
            $stmt = $conn->prepare("INSERT INTO visitantes (nombre, correo, telefono, curp, motivo, hora_entrada, credencial, qr_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssis", $nombre, $correo, $telefono, $curp, $motivo, $hora_entrada, $credencial, $qr_code);

            if ($stmt->execute()) {
                echo "Registro de entrada completado exitosamente. Tu credencial es: " . $credencial;

                // Actualizar el estado de la credencial a 'en uso' y guardar el QR
                $stmtUpdate = $conn->prepare("UPDATE credenciales SET estado = 'en uso', qr_code = ? WHERE credencial = ?");
                $stmtUpdate->bind_param("si", $qr_code, $credencial);
                $stmtUpdate->execute();
                $stmtUpdate->close();

                // Insertar en la tabla historial_visitantes
                $stmtHistorial = $conn->prepare("INSERT INTO historial_visitantes (id, nombre, correo, telefono, hora_entrada, fecha_registro, motivo, curp, credencial, qr_code) VALUES (?, ?, ?, ?, ?, CURDATE(), ?, ?, ?, ?)");
                $stmtHistorial->bind_param("issssssis", $credencial, $nombre, $correo, $telefono, $hora_entrada, $motivo, $curp, $credencial, $qr_code);
                $stmtHistorial->execute();
                $stmtHistorial->close();
            } else {
                echo "Error en el registro de entrada: " . $stmt->error;
            }

            $stmt->close();
            $conn->close();
        } else {
            echo "No hay credenciales disponibles o completa todos los campos de entrada.";
        }

    // Registro de salida
    } elseif ($tipo == "salida") {
        // Buscar la credencial asociada al correo ingresado
        $stmt = $conn->prepare("SELECT credencial FROM visitantes WHERE correo = ? AND credencial IS NOT NULL");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $credencial_salida = $row['credencial'];

            $hora_salida = date('Y-m-d H:i:s');

            // Actualizar la hora de salida en la tabla visitantes
            $stmt = $conn->prepare("UPDATE visitantes SET hora_salida = ?, credencial = NULL WHERE correo = ? AND credencial = ?");
            $stmt->bind_param("ssi", $hora_salida, $correo, $credencial_salida);

            if ($stmt->execute()) {
                echo "Registro de salida completado exitosamente.";

                // Actualizar el estado de la credencial a 'disponible'
                $stmtUpdate = $conn->prepare("UPDATE credenciales SET estado = 'disponible', qr_code = NULL WHERE credencial = ?");
                $stmtUpdate->bind_param("i", $credencial_salida);
                $stmtUpdate->execute();
                $stmtUpdate->close();

                // Actualizar la hora de salida en la tabla historial_visitantes
                $stmtHistorial = $conn->prepare("UPDATE historial_visitantes SET hora_salida = ? WHERE correo = ? AND credencial = ?");
                $stmtHistorial->bind_param("ssi", $hora_salida, $correo, $credencial_salida);
                $stmtHistorial->execute();
                $stmtHistorial->close();
            } else {
                echo "Error en el registro de salida: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "No se encontró una credencial asociada con ese correo.";
        }

        $conn->close();
    }
}
?>