<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datos Administrativos</title>
    <link rel="stylesheet" href="css/secre.css">
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD SECRETARIO</h1>
    </div>
    <section class="datos-administrativos">

        <div class="sub-banner">
            <h2>Datos Administrativos</h2>
        </div>

        <!-- Apartado de Registro de Grupos -->
        <div class="apartado-grupos">
            <h3>Seleccionar Grupo</h3>
            <label for="grupo">Grupo:</label>
            <select id="grupo">
                <option value="1">1</option>
                <option value="2">2</option>
            </select>

            <label for="grado">Grado:</label>
            <select id="grado">
                <option value="A">A</option>
            </select>

            <label for="turno">Turno:</label>
            <select id="turno">
                <option value="matutino">Matutino</option>
                <option value="vespertino">Vespertino</option>
            </select>
            <button id="buscar-grupo">Buscar</button>

            <div id="lista-grupos">
                <h3>Lista de Alumnos</h3>
                <ul id="lista-alumnos-grupos">
                    <!-- Lista de alumnos se llenará dinámicamente -->
                </ul>
            </div>
        </div>

        <!-- Apartado de Búsqueda por Matrícula -->
        <div class="apartado-matricula">
            <h3>Buscar por Matrícula</h3>
            <label for="matricula">Matrícula:</label>
            <input type="text" id="matricula" placeholder="Ingresa matrícula">
            <button id="buscar-matricula">Buscar</button>

            <div id="datos-alumno">
                <!-- Datos del alumno se llenarán dinámicamente -->
            </div>
        </div>

        <!-- Apartado de Búsqueda de Personal -->
        <div class="apartado-personal">

            <div id="lista-personal">
                <h3>Lista de Personal</h3>

                <h4>Turno Matutino</h4>
                <table>
                    <thead>
                        <tr>
                            <th>Nombre Completo</th>
                            <th>Cargo</th>
                            <th>Asistencias</th>
                            <th>Faltas</th>
                            <th>Permisos Otorgados</th>
                            <th>Permisos Solicitados</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Juan Pérez González</td>
                            <td>Profesor de Matemáticas</td>
                            <td>20</td>
                            <td>2</td>
                            <td>1</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>María López Hernández</td>
                            <td>Coordinadora Académica</td>
                            <td>19</td>
                            <td>3</td>
                            <td>0</td>
                            <td>1</td>
                        </tr>
                        <tr>
                            <td>Carlos Ruiz Martínez</td>
                            <td>Profesor de Historia</td>
                            <td>18</td>
                            <td>4</td>
                            <td>1</td>
                            <td>1</td>
                        </tr>
                        <tr>
                            <td>Ana Torres Fernández</td>
                            <td>Secretaria Administrativa</td>
                            <td>21</td>
                            <td>1</td>
                            <td>2</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>Laura González Pérez</td>
                            <td>Profesor de Lengua Española</td>
                            <td>20</td>
                            <td>2</td>
                            <td>1</td>
                            <td>1</td>
                        </tr>
                    </tbody>
                </table>

                <h4>Turno Vespertino</h4>
                <table>
                    <thead>
                        <tr>
                            <th>Nombre Completo</th>
                            <th>Cargo</th>
                            <th>Asistencias</th>
                            <th>Faltas</th>
                            <th>Permisos Otorgados</th>
                            <th>Permisos Solicitados</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Pedro Martínez Gómez</td>
                            <td>Profesor de Ciencias</td>
                            <td>22</td>
                            <td>1</td>
                            <td>0</td>
                            <td>2</td>
                        </tr>
                        <tr>
                            <td>Claudia Morales Silva</td>
                            <td>Psicóloga Escolar</td>
                            <td>20</td>
                            <td>2</td>
                            <td>1</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>Ricardo Sánchez Castillo</td>
                            <td>Profesor de Geografía</td>
                            <td>19</td>
                            <td>3</td>
                            <td>0</td>
                            <td>1</td>
                        </tr>
                        <tr>
                            <td>Isabel Castro Rojas</td>
                            <td>Bibliotecaria</td>
                            <td>21</td>
                            <td>1</td>
                            <td>2</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>Fernando Jiménez López</td>
                            <td>Asistente Administrativo</td>
                            <td>20</td>
                            <td>2</td>
                            <td>1</td>
                            <td>1</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div id="asistencias">
                <!-- Detalles de asistencias se llenarán dinámicamente -->
            </div>
        </div>

        <!-- Apartado de Documentación Escolar -->
        <div class="apartado-documentacion">
            <h3>Documentación Escolar</h3>
            <label for="documento">Seleccionar:</label>
            <select id="documento">
                <option value="plan-estudio">Planes de Estudio</option>
                <option value="reglamento">Reglamento</option>
                <option value="politicas">Políticas de la Institución</option>
            </select>
            <button id="mostrar-documentacion">Mostrar</button>

            <div id="resultado-documentacion">
                <!-- Resultados de documentación se llenarán dinámicamente -->
            </div>
        </div>
    </section>

    <?php include 'footer/footer.php'; ?>

    <script src="js/secre.js"></script>
</body>

</html>
