<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del SuperAdmin</title>
    <link rel="stylesheet" href="css/superadmin.css">
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD SUPERADMIN</h1>
    </div>
    <section class="dashboard">
        <div class="escuelas-vinculadas">
            <h2>Escuelas vinculadas:</h2>
            <p>En total de escuelas son 20.</p>
        </div>
        <div class="asignacion-roles">
            <h2>Asignacion de roles:</h2>
            <ul>
                <li>luis - <span>Maestro</span></li>
                <li>Juana - <span>Supervisor</span></li>
                <li>Karen - <span>Orientador</span></li>
                <li>Carlos - <span>Secretario</span></li>
            </ul>
        </div>
        <div class="lista-supervisores">
            <h2>Lista de supervisores:</h2>
            <ul>
                <li>luis</li>
                <li>Juana</li>
                <li>Karen</li>
                <li>Carlos</li>
            </ul>
        </div>
        <div class="gestion-grupos">
            <h2>Gestion de grupos:</h2>
            <p>Chat 1 telegram</p>
            <ul>
                <li>Agregar grupo</li>
                <li>Borrar</li>
                <li>Gestionar chat</li>
            </ul>
        </div>
        <div class="lista-escuelas">
            <h2>Lista de escuelas:</h2>
            <ul>
                <li>UTC</li>
                <li>TESOEM</li>
                <li>TESCHA</li>
                <li>TEC</li>
            </ul>
        </div>
    </section>

    <?php include 'footer/footer.php'; ?>

</body>

</html>