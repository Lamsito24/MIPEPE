<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Supervisor</title>
    <link rel="stylesheet" href="css/supervisor.css">
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD SUPERVISOR</h1>
    </div>

    <div class="container">
        <div class="card">
            <div class="linked-teachers">
                <h3 class="rounded-border button-like">Maestros vinculados:</h3>
                <p>En total de maestros en la escuela son 20.</p>
            </div>
            <div class="linked-guides">
                <h3 class="rounded-border button-like">Orientadores vinculados:</h3>
                <p>En total de orientadores en la escuela son 16.</p>
            </div>
            <div class="linked-directors">
                <h3 class="rounded-border button-like">Directores vinculados:</h3>
                <p>En total de directores en la escuela son 8.</p>
            </div>
            
            <!-- Nuevo título para la gráfica -->
            <div class="progress-container">
    <h3 class="progress-title">Progreso en grados:</h3>
    <!-- Contenedor para la gráfica -->
    <div class="chart-container">
        <canvas id="progressChart"></canvas>
    </div>
    <p class="progress-info">En primer grado, 25% de los alumnos han reprobado.<br>
       En segundo grado, 28% de los alumnos han reprobado.<br>
       En tercer grado, 15% de los alumnos han reprobado.</p>
</div>



            <div class="group-teachers">
                <h3 class="rounded-border button-like">Grupo de maestros:</h3>
                <p>Juan se encarga del grupo B de los tres grados.</p>
                <p>Profesora Luisa:<br>1a, 2b, 3c.</p>
            </div>
            <div class="group-guides">
                <h3 class="rounded-border button-like">Grupo de orientadores:</h3>
                <p>Orientador Luis:<br>1a.</p>
                <p>Orientador Carlos:<br>3b.</p>
            </div>
        </div>
    </div>

    <?php include 'footer/footer.php'; ?>

    <!-- Script para la gráfica de progreso -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('progressChart').getContext('2d');
        const progressChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Primer grado', 'Segundo grado', 'Tercer grado'],
                datasets: [{
                    label: 'Porcentaje de reprobados',
                    data: [25, 28, 15],
                    backgroundColor: ['#ff6384', '#36a2eb', '#ffce56'],
                    borderColor: ['#ff6384', '#36a2eb', '#ffce56'],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>

</html>
