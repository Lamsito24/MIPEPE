<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Visitantes</title>
    <link rel="stylesheet" href="css/visitante.css">
    <script src="assets/plugins/qrCode.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Estilo para centrar los elementos */
        .hero, .registro {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            margin: 20px;
        }

        h1, h2 {
            font-family: 'Arial', sans-serif;
            color: #333;
        }

        /* Estilo de los botones */
        .btn-registro, .btn-ver-registros {
            padding: 15px 30px;
            margin-top: 15px;
            font-size: 16px;
            font-family: 'Arial', sans-serif;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        /* Estilo hover para animación de botones */
        .btn-registro:hover, .btn-ver-registros:hover {
            transform: scale(1.1); /* Aumenta el tamaño del botón al hacer hover */
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15); /* Mejora el efecto de sombra */
            background-color: #0056b3; /* Color de fondo más oscuro al hacer hover */
        }

        /* Estilo para el contenedor del escáner QR */
        #qr-scanner-container {
            margin: 20px 0;
            padding: 20px;
            border: 2px dashed #007bff;
            border-radius: 8px;
            background-color: #f9f9f9;
            width: 90%;
            max-width: 500px;
        }

        /* Estilo del texto en el escáner QR */
        #qr-scanner-container p {
            margin: 0;
            font-size: 14px;
            color: #555;
        }

        /* Estilo para el video de la cámara */
        #video {
            width: 100%;
            border-radius: 8px;
            margin-top: 10px;
        }
    </style>
</head>

<body>

    <?php include 'header/header.php'; ?>

    <div class="hero">
        <h1>DASHBOARD VISITANTES</h1>
        <p>Regístrate para acceder a eventos especiales y conocer más sobre nuestras actividades.</p>
        <button class="btn-registro" onclick="window.location.href='Registros.php';">Quiero Registrarme</button>
    </div>

    <!-- Escáner de código QR -->
    <div class="row justify-content-center mt-5">
    <div class="col-sm-4 shadow p-3">
      <h5 class="text-center">Escanear codigo QR</h5>
      <div class="row text-center">
        <a id="btn-scan-qr" href="#">
          <img src="https://dab1nmslvvntp.cloudfront.net/wp-content/uploads/2017/07/1499401426qr_icon.svg" class="img-fluid text-center" width="175">
        <a/>
        <canvas hidden="" id="qr-canvas" class="img-fluid"></canvas>
        </div>
        <div class="row mx-5 my-3">
        <button class="btn btn-success btn-sm rounded-3 mb-2" onclick="encenderCamara()">Encender camara</button>
        <button class="btn btn-danger btn-sm rounded-3" onclick="cerrarCamara()">Detener camara</button>
      </div>
    </div>
  </div>

    <!-- Botón para ver registros con contraseña -->
    <div class="registro">
        <h2>Ver Registros</h2>
        <button class="btn-ver-registros" onclick="verRegistros()">Ver Registros</button>
    </div>

    <script>
        // Función para solicitar acceso a la cámara
        async function initCamera() {
            const video = document.getElementById('video');
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true });
                video.srcObject = stream;
            } catch (error) {
                console.error("Error al acceder a la cámara: ", error);
                alert("No se pudo acceder a la cámara. Asegúrate de que esté conectada y permite el acceso.");
            }
        }

        // Llama a la función para inicializar la cámara
        initCamera();

        function verRegistros() {
            const password = prompt("Por favor, ingrese la contraseña:");
            if (password === "expecto_patronum") {
                window.location.href = "historial-visitante.php";
            } else {
                alert("Contraseña incorrecta.");
            }
        }
    </script>

    <?php include 'footer/footer.php'; ?>
    <script src="assets/js/index.js"></script>
    <script src="js/visitante.js"></script>
</body>

</html>
